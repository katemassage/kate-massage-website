KATE MASSAGE — UPDATED WEBSITE
Upload index.html to your existing GitHub repository, replacing the old index.html, then commit the change.
In Settings > Pages, use Deploy from a branch, branch main, folder /(root).

Massage menu:
Relaxation Massage — $80
Swedish Massage — $130
Deep Tissue Massage — $180
Hot Stone Massage — $230
Full Body Massage — $280
Aromatherapy Massage — $330
Premium Signature Massage — $380

Service area: USA
Phone/text: 865-375-2664
Zangi ID: 1007166302
iMessage/email: katemassagebooking@gmail.com
Signal: 979-559-0880

The appointment form prepares an SMS on the visitor's phone. It does not send automatically or process payments.
The added service types and prices should be reviewed and confirmed by the business owner before publishing.
